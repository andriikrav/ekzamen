﻿using System;
using System.Collections.Generic;
using System.Linq;

//створюємо простір імен University
namespace University
{
    public class listHuman //публічний клас listHuman
    {
        //створення приватних змінних класу
        private List<Human> listHumans;

        //конструктори
        public listHuman()
        {
            listHumans = new List<Human>();
        }


        public List<Human> List
        {
            get { return listHumans; }
            set { this.listHumans = value; }
        }

        //методи класу
        //метод додавання обьекта класу Human
        public void AddHuman(Human a) 
        {
            listHumans.Add(a);
        }

        //метод виводу на екран
        public void printHumans()
        {
            for (int i = 0; i < listHumans.Count(); i++)
            {
                listHumans[i].printInfo();
                Console.WriteLine("________________________________");
            }
        }

        //метод друкування об'єктів по імені
        public void printObjByName(string name) 
        {
            for (int i = 0; i < listHumans.Count(); i++)
            {
                if (listHumans[i].Name == name)
                {
                    listHumans[i].printInfo();
                }

            }
        }

        //метод зміни об'єкта по імені
        public void changeObjByName(string name) 
        {
            for (int i = 0; i < listHumans.Count(); i++)
            {
                if (listHumans[i].Name == name)
                {
                    listHumans[i].changeInfo();
                }

            }
        }

        //метод відображення списка в текстовому форматі
        public string showListStr() 
        {
            string listData = "";
            for (int i = 0; i < listHumans.Count(); i++)
                listData += listHumans[i].dataToStr();
            return listData;
        }

        //метод сортування по віку по зростанню
        public void sortByAgeLowToHigh() 
        {
            List<Human> list = listHumans;
            Human temp;
            for (int i = 1; i < list.Count(); i++)
            {
                for (int j = 1; j < list.Count(); j++)
                {
                    if (list[j] < list[j - 1])
                    {
                        temp = list[j];
                        list[j] = list[j - 1];
                        list[j - 1] = temp;
                    }
                }
            }
        }

        //метод сортування по віку по спаданню
        public void sortByAgeHightToLow() 
        {
            List<Human> list = listHumans;
            Human temp;
            for (int i = 1; i < list.Count(); i++)
            {
                for (int j = 1; j < list.Count(); j++)
                {
                    if (list[j] > list[j - 1])
                    {
                        temp = list[j];
                        list[j] = list[j - 1];
                        list[j - 1] = temp;
                    }
                }
            }
        }
    }
}
