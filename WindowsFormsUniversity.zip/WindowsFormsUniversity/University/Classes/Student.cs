﻿using System;
using System.Collections.Generic;

//створюємо простір імен University
namespace University
{
    public class Student : Human //публічний клас Student який є дочірним від класа Human
    {
        //створення приватних змінних класу
        private int _admissionYear;
        private List<Subject> _subjectSet;
        private List<List<string>> _grades;

        //конструктори
        //конструктор за замовчуванням
        public Student() : base() 
        {
            this._admissionYear = 2021;
        }
        //констуктор з параметром
        public Student(string name, string surname, int age, Adress adress,int admissionYear) : base(name, surname, age, adress)
        {
            this._admissionYear = admissionYear;
        }


        //методи доступу до змінних класу
        public int AdmissionYear
        {
            get { return this._admissionYear; }
            set { this._admissionYear = value; }
        }

        public List<List<string>> Grades
        {
            get { return this._grades; }
            set { this._grades = value; }
        }

        //методи класу
        public string dataToStr()
        {
            string str;
            str = base.dataToStr() + "\n" + "Subject: " + _admissionYear.ToString() + "\n" + "Person Data:";
            return str;
        }
    }
}
