﻿using System;
using System.Collections.Generic;
using System.Linq;

//створюємо простір імен University
namespace University
{
    public class listTeacher : listHuman //публічний клас listTeacher який є дочірним від класа listHuman
    {
        //створення приватних змінних класу
        private List<Teacher> _listTeachers;

        //конструктори
        public listTeacher()
        {
            _listTeachers = new List<Teacher>();
        }

        //методи доступу до змінних класу
        public List<Teacher> List
        {
            get { return _listTeachers; }
            set { this._listTeachers = value; }
        }

        //метод створення нового обьекта класу Teacher
        public void addNewTeacher(Teacher teacher)
        {
            _listTeachers.Add(teacher);
        }

        //метод додавання обьекта класу Teacher
        public void AddTeacher(Teacher a) 
        {
            _listTeachers.Add(a);
        }
        public void printTeachers() //метод виводу на екран
        {
            for (int i = 0; i < _listTeachers.Count(); i++)
            {
                _listTeachers[i].printInfo();
                Console.WriteLine("________________________________");
            }
        }

        //метод друкування об'єктів по імені
        public void printObjByName(string name)
        {
            for (int i = 0; i < _listTeachers.Count(); i++)
            {
                if (_listTeachers[i].Name == name)
                {
                    _listTeachers[i].printInfo();
                }
            }
        }

        //метод відображення списка в текстовому форматі
        public string showListStr()
        {
            string listData = "";
            for (int i = 0; i < _listTeachers.Count(); i++)
                listData += _listTeachers[i].dataToStr();
            return listData;
        }
    }
}
