﻿using System;
using System.Collections.Generic;

//створюємо простір імен University
namespace University
{
    enum Subject { None, Math, Fisics, History, Biology, English } //створення перерахування предметів(Subject)

    public class Teacher : Human //публічний клас Teacher який є дочірним від класа Human
    {
        //створення приватних змінних класу
        private Subject _subject;
        private List<Student> _students;
        private int _salary;

        //конструктори
        public Teacher() : base() //конструктор за замовчуванням
        {
            _students = new List<Student>();
                this._subject = Subject.None;
            this._salary = 6500;
        }
        public Teacher(string name, string surname, int age, Adress adress, int salary) : base(name, surname, age, adress) //констуктор з параметром
        {
            _students = new List<Student>();
            this._salary = salary;
        }

        //методи доступу до змінних класу
        public List<Student> Students
        {
            get { return _students; }
            set { _students = value; }
        }
        public int salary
        {
            get { return _salary; }
            set { _salary = value; }
        }

        //методи класу
        //метод що певертає данні викладача в тектовому форматі
        public string getStudentsStr() 
        {
            string result = "";
            for (int i = 0; i < _students.Count; i++) {
                result += _students[i].Name + " " + _students[i].Surname + "\n";
                    }
            return result;
        }

        //друкування данних
        public void printInfo() 
        {
            Console.WriteLine(dataToStr());
        }

        //метод переводу всіх данних в строчні змінні для виводу на екран
        public string dataToStr()
        {
            string str;
            str = base.dataToStr() + "\n" + "Subject: " + _subject.ToString() + "\n" + "Salary" + _salary + "\n" + "Person Data:";
            return str;
        }

        // метод додавання нового студента
        public void AddStudent(Student student) 
        {
            _students.Add(student);
        }
    }
}

